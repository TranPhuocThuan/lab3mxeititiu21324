/*
 * global.c
 *
 *  Created on: Nov 5, 2023
 *      Author: AD
 */
#include "global.h"

int mode=0;
int time_red=5;
int time_green=3;
int time_yellow=2;
int clear_all_traffic_led=0;

