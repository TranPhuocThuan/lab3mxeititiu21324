/*
 * yellow_mode.h
 *
 *  Created on: Nov 14, 2023
 *      Author: AD
 */

#ifndef INC_YELLOW_MODE_H_
#define INC_YELLOW_MODE_H_

#include "main.h"

void yellowMode();
void setTimeYellow();

#endif /* INC_YELLOW_MODE_H_ */
