/*
 * red_man.h
 *
 *  Created on: Nov 14, 2023
 *      Author: AD
 */

#ifndef INC_RED_MODE_H_
#define INC_RED_MODE_H_

#include "main.h"

void redMode();
void setTimeRed();


#endif /* INC_RED_MODE_H_ */
