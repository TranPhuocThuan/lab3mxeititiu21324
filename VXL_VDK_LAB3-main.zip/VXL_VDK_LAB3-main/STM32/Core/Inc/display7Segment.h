/*
 * display7Segment.h
 *
 *  Created on: Nov 6, 2023
 *      Author: AD
 */

#ifndef INC_DISPLAY7SEGMENT_H_
#define INC_DISPLAY7SEGMENT_H_

#include <main.h>

#define LED_7SEG_12 0
#define LED_7SEG_34 1

void display7Segment12(int);
void display7Segment34(int);

#endif /* INC_DISPLAY7SEGMENT_H_ */
