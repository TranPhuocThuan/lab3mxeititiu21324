/*
 * green_mode.h
 *
 *  Created on: Nov 14, 2023
 *      Author: AD
 */

#ifndef INC_GREEN_MODE_H_
#define INC_GREEN_MODE_H_

#include "main.h"

void greenMode();
void setTimeGreen();

#endif /* INC_GREEN_MODE_H_ */
