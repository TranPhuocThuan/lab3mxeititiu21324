/*
 * mode1.h
 *
 *  Created on: Nov 12, 2022
 *      Author: PC
 */

#ifndef INC_MODE_H_
#define INC_MODE_H_

#include "global.h"
#include "modify.h"

void mode2_run();
void mode3_run();
void mode4_run();
#endif /* INC_MODE_H_ */
