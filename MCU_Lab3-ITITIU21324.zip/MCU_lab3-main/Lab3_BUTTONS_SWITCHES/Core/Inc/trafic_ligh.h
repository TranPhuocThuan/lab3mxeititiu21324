/*
 * trafic_ligh.h
 *
 *  Created on: Nov 1, 2022
 *      Author: PC
 */

#ifndef INC_TRAFIC_LIGH_H_
#define INC_TRAFIC_LIGH_H_

#include "seven_seg_led_display.h"
#include "software_timer.h"
#include "main.h"

void trafic_light_run();

#endif /* INC_TRAFIC_LIGH_H_ */
