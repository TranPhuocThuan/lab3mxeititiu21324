/*
 * modify.h
 *
 *  Created on: Nov 12, 2022
 *      Author: PC
 */

#ifndef INC_MODIFY_H_
#define INC_MODIFY_H_

#include "global.h"

void modify_run(int led);

#endif /* INC_MODIFY_H_ */
