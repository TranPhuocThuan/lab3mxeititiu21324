/*
 * selecting_mode.h
 *
 *  Created on: Nov 1, 2022
 *      Author: PC
 */

#ifndef INC_SELECTING_MODE_H_
#define INC_SELECTING_MODE_H_

#include <mode.h>
#include "global.h"
#include "trafic_ligh.h"

void selecting_mode_run();

#endif /* INC_SELECTING_MODE_H_ */
